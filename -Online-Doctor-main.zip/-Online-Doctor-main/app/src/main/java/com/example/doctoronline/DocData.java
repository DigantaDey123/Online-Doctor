package com.example.doctoronline;

public class DocData {

    private String name;
    private String id;
    private String chember;
    private String speciality;
    private String email;
    private String phone;
    private String location;

    public String count;


    public String  getPhone() {
        return phone;
    }
    public String  getSpeciality() {
        return speciality;
    }
    public String getChember() {
        return chember;
    }
    public String  getLocation() {
        return location;
    }
    public String getCount() {
        return count;
    }
    public String getName() {
        return name;
    }
    public String getId() {
        return id;
    }
}
